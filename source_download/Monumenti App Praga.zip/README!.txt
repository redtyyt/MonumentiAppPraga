Ciao!
Sono RedTy (https://github.com/redtyyt) e l'applicazione che hai scaricato è "Monumenti App Praha", il sequel diverso di maL(https://github.com/redtyyt/MonumentiAppLondon).

Step per aprire l'app:
	
	1. Estrarre i file dalla cartella (non necessariamente anche il file .pdb);
	
	2. Avviare "Monumenti App Praga.exe";
	
Troubleshooting:

	1. L'app deve essere chiusa MANUALMENTE dalla gestione attività.